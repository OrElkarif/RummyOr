package com.example.orproject;

public class Card {
        private String value;         // הערך של הקלף (אס, 2, 3, מלכה וכו')
        private String suit;          // סוג הקלף (לב, תלתן, דגלים וכו')
        private int id;               // מזהה ייחודי לכל קלף
        private boolean isRemoved;    // אם הקלף הוסר מהיד


    public String getValue() {
        return value;
    }

    public String getSuit() {
        return suit;
    }

    public int getId() {
        return id;
    }


    public boolean equals()

}
