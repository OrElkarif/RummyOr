package com.example.orproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AchievementsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_achievements);
    }
}